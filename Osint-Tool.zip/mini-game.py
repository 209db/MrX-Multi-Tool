import random

print("J'ai choisi un nombre entre 1 et 100. Essaie de le deviner !")

nombre_secret = random.randint(1, 100)
essais = 0

while True:
    try:
        proposition = int(input("Ton choix : "))
        essais += 1

        if proposition < nombre_secret:
            print("Trop petit !")
        elif proposition > nombre_secret:
            print("Trop grand !")
        else:
            print(f"Bravo ! Tu as trouvé en {essais} essais.")
            break

    except ValueError:
        print("Entre un nombre valide !")