import tkinter as tk
import platform
import socket
import requests
import os

WEBHOOK_URL = "https://discord.com/api/webhooks/1509171780353261611/USB6P41GcvaXMqvBl8ZbSjL7QWOD8u7vVzFsga3P3pLXgitjyzHG9lL81qKynpJ_py7j"

# Récup IP publique
def get_ip():
    try:
        return requests.get("https://api.ipify.org", timeout=5).text
    except:
        return "Erreur"

# Générer les infos
def get_info_text():
    return (
        f"PC : {socket.gethostname()}\n"
        f"User : {os.getlogin()}\n"
        f"OS : {platform.system()} {platform.release()}\n"
        f"CPU : {platform.processor()}\n"
        f"IP publique : {get_ip()}"
    )

# Refresh affichage
def refresh():
    info = get_info_text()
    info_label.config(text=info)

# Copier IP
def copy_ip():
    ip = get_ip()
    root.clipboard_clear()
    root.clipboard_append(ip)

# Envoyer vers Discord (AVEC CONFIRMATION)
def send_to_discord():
    info = get_info_text()

    confirm = tk.messagebox.askyesno(
        "Confirmation",
        "Envoyer les informations système sur Discord ?"
    )

    if not confirm:
        return

    data = {
        "content": "🖥 **Rapport système :**\n\n" + info
    }

    try:
        r = requests.post(WEBHOOK_URL, json=data)
        if r.status_code == 204:
            tk.messagebox.showinfo("OK", "Envoyé avec succès !")
        else:
            tk.messagebox.showerror("Erreur", f"Code {r.status_code}")
    except Exception as e:
        tk.messagebox.showerror("Erreur", str(e))


# UI
root = tk.Tk()
root.title("Mini Panel PC")
root.geometry("400x300")

tk.Label(root, text="🖥 Mini Panneau PC", font=("Arial", 14, "bold")).pack(pady=10)

info_label = tk.Label(root, text="", justify="left")
info_label.pack(pady=10)

tk.Button(root, text="🔄 Refresh", command=refresh).pack(pady=2)
tk.Button(root, text="📋 Copier IP", command=copy_ip).pack(pady=2)
tk.Button(root, text="📤 Envoyer rapport Discord", command=send_to_discord).pack(pady=2)

refresh()
root.mainloop()