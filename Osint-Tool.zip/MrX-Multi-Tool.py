import tkinter as tk
import webbrowser
from tkinter import simpledialog
import urllib.request
import json
import winsound
import random

# ➕ AJOUT OSINT IMAGE
from tkinter import filedialog
from PIL import Image, ExifTags


# ---------------- CONFIG ----------------
SECRET_CODE = "04123"
URL = "https://discord.gg/sdpPuNXd"
GITHUB = "https://github.com/209db"

# ---------------- THEME CYBER ----------------
BG = "#07090d"
PANEL = "#0d1117"
NEON = "#00ff88"
RED = "#ff2e2e"
TEXT_DIM = "#7a7a7a"
ENTRY_BG = "#0b0f14"

FONT = ("Consolas", 11)
FONT_BIG = ("Consolas", 16, "bold")
FONT_SMALL = ("Consolas", 9)

# ---------------- LOGIN ----------------
def check_code():
    if entry.get() == SECRET_CODE:
        flash_screen(NEON)
        hacker_message("SYSTEM UNLOCKED")

        title.pack_forget()
        entry.pack_forget()
        check_btn.pack_forget()

        create_nagoya_button()

    else:
        flash_screen(RED)
        hacker_message("ACCESS DENIED")

def go_to_nagoya():
    webbrowser.open(URL)

# ---------------- MULTICOLOR ANIMATION ----------------
colors = ["#00ff88", "#00ffff", "#ff00ff", "#ffff00", "#ff2e2e"]

def rainbow_loop(btn):
    btn.config(fg=random.choice(colors))
    root.after(120, lambda: rainbow_loop(btn))

# ---------------- CREATE BUTTON ----------------
def create_nagoya_button():
    global nagoya_btn

    if "nagoya_btn" not in globals():
        nagoya_btn = make_btn("GO TO NAGOYA", go_to_nagoya)

        nagoya_btn.pack_forget()
        nagoya_btn.pack(pady=5, before=hacker_label)

        rainbow_loop(nagoya_btn)

# ---------------- GITHUB ----------------
def open_github(event=None):
    winsound.MessageBeep(winsound.MB_OK)
    webbrowser.open(GITHUB)

# ---------------- HACKER TEXT ----------------
def hacker_message(text):
    hacker_label.config(text="")
    chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%&"

    def animate(i=0):
        if i <= len(text):
            fake = ''.join(random.choice(chars) for _ in range(len(text)-i))
            hacker_label.config(text=text[:i] + fake)
            root.after(35, lambda: animate(i+1))
        else:
            hacker_label.config(text=text)

    animate()

# ---------------- FLASH ----------------
def flash_screen(color):
    overlay = tk.Frame(root, bg=color)
    overlay.place(relwidth=1, relheight=1)
    root.after(120, overlay.destroy)

# ---------------- MATRIX ----------------
matrix_chars = []

def create_matrix():
    for _ in range(80):
        x = random.randint(0, 360)
        y = random.randint(-500, 0)

        txt = matrix.create_text(
            x, y,
            text=random.choice("01#$@"),
            fill=NEON,
            font=("Consolas", 10, "bold")
        )

        matrix_chars.append([txt, random.randint(3, 12)])

def animate_matrix():
    for item, speed in matrix_chars:
        matrix.move(item, 0, speed)
        x, y = matrix.coords(item)

        if y > 520:
            matrix.coords(item, random.randint(0, 360), random.randint(-200, 0))

    root.after(40, animate_matrix)

# ---------------- OSINT ----------------
def scan_pseudo():
    pseudo = simpledialog.askstring("OSINT", "GitHub username:")
    if not pseudo:
        return

    url = f"https://api.github.com/users/{pseudo}"

    try:
        data = json.loads(urllib.request.urlopen(url, timeout=5).read().decode())

        result_text = f"""[ OSINT REPORT ]

USER: {data['login']}
ID: {data['id']}
REPOS: {data['public_repos']}
FOLLOWERS: {data['followers']}
URL: {data['html_url']}
CREATED: {data['created_at']}"""

    except:
        result_text = "ERROR: USER NOT FOUND"

    popup(result_text, "OSINT RESULT")

# ---------------- IP ----------------
def ip_locator():
    ip = simpledialog.askstring("IP", "Public IP:")
    if not ip:
        return

    try:
        url = f"http://ip-api.com/json/{ip}"
        data = json.loads(urllib.request.urlopen(url, timeout=5).read().decode())

        if data["status"] != "success":
            result_text = "INVALID IP"
        else:
            result_text = f"""[ IP REPORT ]

IP: {data['query']}
CITY: {data['city']}
REGION: {data['regionName']}
COUNTRY: {data['country']}
ISP: {data['isp']}
LOC: {data['lat']}, {data['lon']}"""

    except:
        result_text = "NETWORK ERROR"

    popup(result_text, "IP LOCATOR")

# ---------------- ➕ OSINT IMAGE (AJOUT) ----------------
def osint_image():
    path = filedialog.askopenfilename(filetypes=[("Images", "*.png *.jpg *.jpeg")])
    if not path:
        return

    try:
        img = Image.open(path)
        exif = img._getexif()

        date_taken = "UNKNOWN"
        gps_info = "UNKNOWN"

        if exif:
            for tag, value in exif.items():
                decoded = ExifTags.TAGS.get(tag, tag)

                if decoded == "DateTimeOriginal":
                    date_taken = value

                if decoded == "GPSInfo":
                    gps_info = str(value)

        result_text = f"""[ IMAGE OSINT REPORT ]

FILE: {path}
DATE TAKEN: {date_taken}
GPS DATA: {gps_info}
"""

    except:
        result_text = "ERROR: Cannot read image metadata"

    popup(result_text, "IMAGE OSINT")

# ---------------- POPUP ----------------
def popup(text, title):
    win = tk.Toplevel(root)
    win.title(title)
    win.geometry("420x280")
    win.configure(bg=PANEL)

    tk.Label(
        win,
        text=text,
        justify="left",
        bg=PANEL,
        fg=NEON,
        font=("Consolas", 10)
    ).pack(pady=20, padx=15)

# ---------------- LOGO ----------------
x_speed = 2
x_pos = 0

def animate_logo():
    global x_speed, x_pos
    x_pos += x_speed

    if x_pos > 20 or x_pos < -20:
        x_speed *= -1

    logo.move("logo", x_speed, 0)
    root.after(25, animate_logo)

# ---------------- HOVER ----------------
def on_enter(e): e.widget.config(bg=NEON, fg="black")
def on_leave(e): e.widget.config(bg="#111", fg=NEON)

# ---------------- WINDOW ----------------
root = tk.Tk()
root.title("NAGOYA ACCESS SYSTEM")
root.geometry("380x520")
root.configure(bg=BG)
root.resizable(False, False)

# ---------------- MATRIX ----------------
matrix = tk.Canvas(root, bg=BG, highlightthickness=0)
matrix.place(x=0, y=0, relwidth=1, relheight=1)

create_matrix()
animate_matrix()

# ---------------- LOGO ----------------
logo = tk.Canvas(root, width=140, height=140, bg=BG, highlightthickness=0)
logo.pack(pady=15)

logo.create_text(70, 60, text="NAGOYA", fill=NEON, font=("Consolas", 14, "bold"), tags="logo")
logo.create_text(70, 15, text="> SYSTEM ONLINE <", fill=TEXT_DIM, font=FONT_SMALL, tags="logo")

logo.tag_bind("logo", "<Button-1>", open_github)

# ---------------- TITLE ----------------
title = tk.Label(
    root,
    text="ACCESS TERMINAL",
    bg=BG,
    fg=NEON,
    font=FONT_BIG
)
title.pack(pady=5)

# ---------------- ENTRY ----------------
entry = tk.Entry(
    root,
    show="*",
    bg=ENTRY_BG,
    fg=NEON,
    insertbackground=NEON,
    relief="flat",
    font=FONT,
    justify="center"
)
entry.pack(pady=10, ipady=6)

# ---------------- BUTTON FACTORY ----------------
def make_btn(text, cmd):
    b = tk.Button(
        root,
        text=text,
        command=cmd,
        bg="#111",
        fg=NEON,
        activebackground=NEON,
        activeforeground="black",
        relief="flat",
        font=FONT,
        padx=10,
        pady=4
    )
    b.pack(pady=4)
    b.bind("<Enter>", on_enter)
    b.bind("<Leave>", on_leave)
    return b

# ---------------- BUTTONS ----------------
check_btn = make_btn("VALIDATE CODE", check_code)
scan_btn = make_btn("GITHUB OSINT SCAN", scan_pseudo)
ip_btn = make_btn("IP LOCATOR", ip_locator)

# ➕ AJOUT BOUTON OSINT IMAGE
img_btn = make_btn("OSINT IMAGE", osint_image)

# ---------------- TERMINAL ----------------
hacker_label = tk.Label(
    root,
    text="",
    bg=BG,
    fg=NEON,
    font=("Consolas", 10)
)
hacker_label.pack(pady=12)

# ---------------- ✨ INTRO ANIMATION ----------------
def show_intro():
    intro = tk.Frame(root, bg=BG)
    intro.place(relwidth=1, relheight=1)

    intro_label = tk.Label(
        intro,
        text="",
        bg=BG,
        fg=NEON,
        font=("Consolas", 20, "bold")
    )
    intro_label.place(relx=0.5, rely=0.45, anchor="center")

    sub_label = tk.Label(
        intro,
        text="",
        bg=BG,
        fg=TEXT_DIM,
        font=("Consolas", 9)
    )
    sub_label.place(relx=0.5, rely=0.55, anchor="center")

    MESSAGE = "BONJOUR PETIT FARFADET !"
    chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%&"

    def animate_text(i=0):
        if i <= len(MESSAGE):
            fake = ''.join(random.choice(chars) for _ in range(len(MESSAGE) - i))
            intro_label.config(text=MESSAGE[:i] + fake)
            root.after(50, lambda: animate_text(i + 1))
        else:
            intro_label.config(text=MESSAGE)
            blink_cursor(0)

    def blink_cursor(n):
        if n < 6:
            cur = "_" if n % 2 == 0 else ""
            sub_label.config(text=f"[ INITIALISATION... {cur} ]")
            root.after(300, lambda: blink_cursor(n + 1))
        else:
            sub_label.config(text="[ INITIALISATION... OK ]")
            root.after(600, lambda: fade_out(intro, 255))

    def fade_out(frame, alpha):
        if alpha > 0:
            color = "#{:02x}{:02x}{:02x}".format(
                max(0, int(7 * alpha / 255)),
                max(0, int(9 * alpha / 255)),
                max(0, int(13 * alpha / 255))
            )
            frame.config(bg=color)
            intro_label.config(bg=color)
            sub_label.config(bg=color)
            root.after(18, lambda: fade_out(frame, alpha - 15))
        else:
            frame.destroy()

    animate_text()

show_intro()

animate_matrix()
animate_logo()
root.mainloop()